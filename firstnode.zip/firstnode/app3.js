const fs = require('fs');


// Writing to a file
fs.writeFile('examplewrite.txt', 'Hello, Node.js!', (err) => {
    if (err) {
        console.error(err);
        return;
    }
    console.log('File written successfully');
});
