// Create a module: myModule.js
exports.myFunction = function() {
    return 'Hello from myModule!';
};

