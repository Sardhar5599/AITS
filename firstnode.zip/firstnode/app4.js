const EventEmitter = require('events');
const eventEmitter = new EventEmitter();

// Create an event handler
const myEventHandler = () => {
    console.log('Event triggered!');
};

// Assign the event handler to an event
eventEmitter.on('myEvent', myEventHandler);

// Fire the event
eventEmitter.emit('myEvent');
