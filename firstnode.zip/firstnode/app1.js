
// Use the module: app1.js
const myModule = require('./myModule');
console.log(myModule.myFunction());