function greet(a,b, callback) {
    
    callback(a,b)
}

function sayGoodbye(a,b) {
    console.log('Sum :'+(a+b));
}

greet(20,40, sayGoodbye);
